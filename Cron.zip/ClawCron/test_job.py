#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright(c): xiaoliang.chen
# Mail: xlchentj@gmail.com
# Created Time: 2016-06-28 16:00:40


from claw_core.log import logging

logger = logging.getLogger(__name__)


def hello_claw_scheduler(test_args):
    logger.info("hello_claw_scheduler, i am is test")
